<?php
    $title_project = 'Enys, le confort énergétique responsable et innovant';
    $host = 'localhost';
    $user = 'root';
    $pass = 'root';
    $db   = 't1';
    try {
        $koneksi = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
        $koneksi->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch (PDOException $e) {
        return 'Connection failed: ' . $e->getMessage();
    }

?>