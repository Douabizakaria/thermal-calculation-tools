<?php
    // session start
    if(!empty($_SESSION)){ }else{ session_start(); }
    //session
	if(!empty($_SESSION['ADMIN'])){ }else{ header('location:login.php'); }
    // panggil file
    require 'proses/panggil.php';
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Ajouter un Client</title>
        <link rel="stylesheet" href="../../assets/css/bootstrap.css?v=<?=time();?>">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
    <body style="background:#a2c31b;">
	<body class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <b>
                        
                        <img src="../../assets/img/ENYS.png" style="height: 50px;
    display: block;">
                    </b>
                </a>
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation"></button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <?php if(!empty($_SESSION['ADMIN'])){?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Tableau de bord</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php?hal=profil">
                                Modifier le compte
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../proses.php?aksi=logout">
                                    <i class="fa fa-sign-out"></i> Se déconnecter
                                </a>
                            </li>
                        <?php }else{?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Accueil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="login.php">
                                    <i class="fa fa-sign-in"></i> Connectez-vous ici
                                </a>
                            </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
        </nav>
		<div class="container">
			<br/>
            
			<br/><br/><br/>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-lg-12">
					<br/>
					<div class="card">
						<div class="card-header">
						<h4 class="card-title">Données de Client</h4>
						</div>
						<div class="card-body">
                        <form action="piece.php" method="POST">
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="form-group">
          <p class="lead">Composition parois froides</p>
        </div>
        <table class="table table-secondary table-bordered" style="">
          <thead>
            <tr>
              <th>#</th>
              <th>Matériau 1</th>
              <th>Epaisseur (mm)</th>
              <th>Matériau 2</th>
              <th>Epaisseur (mm)</th>
              <th>Matériau 3</th>
              <th>Epaisseur (mm)</th>
              <th>Matériau 4</th>
              <th>Epaisseur (mm)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Plafond</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">Mur</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">Sol</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option id='Neant'>Neant</option>
<option id='vide non ventile 5 mm 011'>vide non ventile 5 mm 011</option>
<option id='vide non ventile 10 mm 015'>vide non ventile 10 mm 015</option>
<option id='vide non ventile 25 mm 019'>vide non ventile 25 mm 019</option>
<option id='vide non ventile 50 mm 021'>vide non ventile 50 mm 021</option>
<option id='vide non ventile 100 mm 022'>vide non ventile 100 mm 022</option>
<option id='vide non ventile 300 mm 023'>vide non ventile 300 mm 023</option>
<option id='vide faiblement ventile 5 mm 0055'>vide faiblement ventile 5 mm 0055</option>
<option id='vide faiblement ventile 10 mm 0075'>vide faiblement ventile 10 mm 0075</option>
<option id='vide faiblement ventile 25 mm 0095'>vide faiblement ventile 25 mm 0095</option>
<option id='vide faiblement ventile 50 mm 0105'>vide faiblement ventile 50 mm 0105</option>
<option id='vide faiblement ventile 100 mm 011'>vide faiblement ventile 100 mm 011</option>
<option id='vide faiblement ventile 300 mm 0115'>vide faiblement ventile 300 mm 0115</option>
<option id='comble + couverture sans soustoiture 006'>comble + couverture sans soustoiture 006</option>
<option id='comble + couverture avec soustoiture 02'>comble + couverture avec soustoiture 02</option>
<option id='comble + couverture avec soustoiture a basse emissivite 03'>comble + couverture avec soustoiture a basse emissivite 03</option>
<option id='brique perforee 1000kg/m3 29/14 int 0380'>brique perforee 1000kg/m3 29/14 int 0380</option>
<option id='brique perforee 1000kg/m3 29/14 ext 0720'>brique perforee 1000kg/m3 29/14 ext 0720</option>
<option id='brique perforee 1000kg/m3 29/19 int 0370'>brique perforee 1000kg/m3 29/19 int 0370</option>
<option id='brique perforee 1000kg/m3 29/19 ext 0700'>brique perforee 1000kg/m3 29/19 ext 0700</option>
<option id='brique perforee 1600kg/m3 19/6 int 0620'>brique perforee 1600kg/m3 19/6 int 0620</option>
<option id='brique perforee 1600kg/m3 19/6 ext 1170'>brique perforee 1600kg/m3 19/6 ext 1170</option>
<option id='brique pleine 2100kg/m3 19/6 int 0830'>brique pleine 2100kg/m3 19/6 int 0830</option>
<option id='brique pleine 2100kg/m3 19/6 ext 1590'>brique pleine 2100kg/m3 19/6 ext 1590</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 int 0260'>bloc beton tres leger 600 kg/m3 39/19 int 0260</option>
<option id='bloc beton tres leger 600 kg/m3 39/19 ext 0410'>bloc beton tres leger 600 kg/m3 39/19 ext 0410</option>
<option id='bloc beton leger 900 kg/m3 39/19 int 0370'>bloc beton leger 900 kg/m3 39/19 int 0370</option>
<option id='bloc beton leger 900 kg/m3 39/19 ext 0560'>bloc beton leger 900 kg/m3 39/19 ext 0560</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 int 0520'>bloc beton moyen 1200 kg/m3 39/19 int 0520</option>
<option id='bloc beton moyen 1200 kg/m3 39/19 ext 0710'>bloc beton moyen 1200 kg/m3 39/19 ext 0710</option>
<option id='bloc beton milourd 1800 kg/m3 int 1210'>bloc beton milourd 1800 kg/m3 int 1210</option>
<option id='bloc beton milourd 1800 kg/m3 ext 1580'>bloc beton milourd 1800 kg/m3 ext 1580</option>
<option id='bloc beton lourd 2400 kg/m3 int 2000'>bloc beton lourd 2400 kg/m3 int 2000</option>
<option id='bloc beton lourd 2400 kg/m3 ext 2620'>bloc beton lourd 2400 kg/m3 ext 2620</option>
<option id='bloc creux beton leger <1200 kg/m3 14 cm 0300'>bloc creux beton leger <1200 kg/m3 14 cm 0300</option>
<option id='bloc creux beton leger <1200 kg/m3 19 cm 0350'>bloc creux beton leger <1200 kg/m3 19 cm 0350</option>
<option id='bloc creux beton leger <1200 kg/m3 29 cm 0450'>bloc creux beton leger <1200 kg/m3 29 cm 0450</option>
<option id='bloc creux beton lourds >1200 kg/m3 14 cm 0110'>bloc creux beton lourds >1200 kg/m3 14 cm 0110</option>
<option id='bloc creux beton lourds >1200 kg/m3 19 cm 0140'>bloc creux beton lourds >1200 kg/m3 19 cm 0140</option>
<option id='bloc creux beton lourds >1200 kg/m3 29 cm 0200'>bloc creux beton lourds >1200 kg/m3 29 cm 0200</option>
<option id='beton cellulaire 400 kg/m3 int 0150'>beton cellulaire 400 kg/m3 int 0150</option>
<option id='beton leger plein 900 kg/m3 int 0250'>beton leger plein 900 kg/m3 int 0250</option>
<option id='beton leger plein 900 kg/m3 ext 0430'>beton leger plein 900 kg/m3 ext 0430</option>
<option id='beton leger plein 1200 kg/m3 int 0370'>beton leger plein 1200 kg/m3 int 0370</option>
<option id='beton leger plein 1200 kg/m3 ext 0580'>beton leger plein 1200 kg/m3 ext 0580</option>
<option id='beton lourd non arme 2200 kg/m3 int 1300'>beton lourd non arme 2200 kg/m3 int 1300</option>
<option id='beton lourd non arme 2200 kg/m3 ext 1700'>beton lourd non arme 2200 kg/m3 ext 1700</option>
<option id='beton lourd arme 2400 kg/m3 int 1700'>beton lourd arme 2400 kg/m3 int 1700</option>
<option id='beton lourd arme 2400 kg/m3 ext 2200'>beton lourd arme 2400 kg/m3 ext 2200</option>
<option id='hourdis en beton e = 12 cm 0110'>hourdis en beton e = 12 cm 0110</option>
<option id='hourdis en beton e = 16 cm 0130'>hourdis en beton e = 16 cm 0130</option>
<option id='hourdis en beton e = 20 cm 0150'>hourdis en beton e = 20 cm 0150</option>
<option id='plancher prefab en terre cuite 1 creux e = 8 cm 0080'>plancher prefab en terre cuite 1 creux e = 8 cm 0080</option>
<option id='plancher prefab en terre cuite 1 creux e = 12 cm 0110'>plancher prefab en terre cuite 1 creux e = 12 cm 0110</option>
<option id='plancher prefab en terre cuite 2 creux e = 12 cm 0130'>plancher prefab en terre cuite 2 creux e = 12 cm 0130</option>
<option id='plancher prefab en terre cuite 2 creux e = 16 cm 0160'>plancher prefab en terre cuite 2 creux e = 16 cm 0160</option>
<option id='plancher prefab en terre cuite 2 creux e = 20 cm 0190'>plancher prefab en terre cuite 2 creux e = 20 cm 0190</option>
<option id='platre avec ou sans granulats legers <800 kg/m3 int 0220'>platre avec ou sans granulats legers <800 kg/m3 int 0220</option>
<option id='platre avec ou sans granulats legers <1100 kg/m3 int 0350'>platre avec ou sans granulats legers <1100 kg/m3 int 0350</option>
<option id='platre avec ou sans granulats legers >1100 kg/m3 int 0520'>platre avec ou sans granulats legers >1100 kg/m3 int 0520</option>
<option id='platre 1300 kg/m3 int 0520'>platre 1300 kg/m3 int 0520</option>
<option id='plaque platre entre deux cartons forts e<14 0050'>plaque platre entre deux cartons forts e<14 0050</option>
<option id='plaque platre entre deux cartons forts e>14 0080'>plaque platre entre deux cartons forts e>14 0080</option>
<option id='mortier de ciment 1900 kg/m3 int 0930'>mortier de ciment 1900 kg/m3 int 0930</option>
<option id='mortier de ciment 1900 kg/m3 ext 1500'>mortier de ciment 1900 kg/m3 ext 1500</option>
<option id='mortier de chaux 1600 kg/m3 int 0700'>mortier de chaux 1600 kg/m3 int 0700</option>
<option id='mortier de chaux 1600 kg/m3 ext 1200'>mortier de chaux 1600 kg/m3 ext 1200</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 int 0130'>bois feuillus durs ou resineux <600 kg/m3 int 0130</option>
<option id='bois feuillus durs ou resineux <600 kg/m3 ext 0150'>bois feuillus durs ou resineux <600 kg/m3 ext 0150</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 int 0180'>bois feuillus durs ou resineux >600 kg/m3 int 0180</option>
<option id='bois feuillus durs ou resineux >600 kg/m3 ext 0200'>bois feuillus durs ou resineux >600 kg/m3 ext 0200</option>
<option id='contreplaque <400 kg/m3 int 0090'>contreplaque <400 kg/m3 int 0090</option>
<option id='contreplaque <400 kg/m3 ext 0110'>contreplaque <400 kg/m3 ext 0110</option>
<option id='contreplaque 400600 kg/m3 int 0130'>contreplaque 400600 kg/m3 int 0130</option>
<option id='contreplaque 400600 kg/m3 ext 0150'>contreplaque 400600 kg/m3 ext 0150</option>
<option id='contreplaque 600850 kg/m3 int 0170'>contreplaque 600850 kg/m3 int 0170</option>
<option id='contreplaque 600850 kg/m3 ext 0200'>contreplaque 600850 kg/m3 ext 0200</option>
<option id='contreplaque >850 kg/m3 int 0240'>contreplaque >850 kg/m3 int 0240</option>
<option id='contreplaque >850 kg/m3 ext 0280'>contreplaque >850 kg/m3 ext 0280</option>
<option id='panneaux particules de bois <450 kg/m2 int 0100'>panneaux particules de bois <450 kg/m2 int 0100</option>
<option id='panneaux particules de bois 450750 kg/m2 int 0140'>panneaux particules de bois 450750 kg/m2 int 0140</option>
<option id='panneaux particules de bois >750 kg/m2 int 0180'>panneaux particules de bois >750 kg/m2 int 0180</option>
<option id='panneaux de fibres de boisciment 1200 kg/m3 int 0230'>panneaux de fibres de boisciment 1200 kg/m3 int 0230</option>
<option id='panneaux osb 650 kg/m3 int 0130'>panneaux osb 650 kg/m3 int 0130</option>
<option id='panneaux fibres de bois <375 kg/m2 int 0070'>panneaux fibres de bois <375 kg/m2 int 0070</option>
<option id='panneaux fibres de bois 375500 kg/m2 int 0100'>panneaux fibres de bois 375500 kg/m2 int 0100</option>
<option id='panneaux fibres de bois 500700 kg/m2 int 0140'>panneaux fibres de bois 500700 kg/m2 int 0140</option>
<option id='panneaux fibres de bois >700 kg/m2 int 0180'>panneaux fibres de bois >700 kg/m2 int 0180</option>
<option id='liege int 0050'>liege int 0050</option>
<option id='laines minerales mw int 0045'>laines minerales mw int 0045</option>
<option id='polystyrene expanse eps int 0045'>polystyrene expanse eps int 0045</option>
<option id='polyethylene extrude int 0045'>polyethylene extrude int 0045</option>
<option id='mousse phenolique revetue pf int 0045'>mousse phenolique revetue pf int 0045</option>
<option id='mousse phenolique a cellules fermees revetue pf int 0030'>mousse phenolique a cellules fermees revetue pf int 0030</option>
<option id='polyurethane revetu pur/pir int 0035'>polyurethane revetu pur/pir int 0035</option>
<option id='polystyrene extrude xps int 0040'>polystyrene extrude xps int 0040</option>
<option id='verre cellulaire cg int 0055'>verre cellulaire cg int 0055</option>
<option id='perlite epb int 0060'>perlite epb int 0060</option>
<option id='vermiculite int 0065'>vermiculite int 0065</option>
<option id='panneaux de vermiculite expansee int 0090'>panneaux de vermiculite expansee int 0090</option>
<option id='carreaux de terre cuite 1700 kg/m3 int 0810'>carreaux de terre cuite 1700 kg/m3 int 0810</option>
<option id='carreaux de terre cuite 1700 kg/m3 ext 1000'>carreaux de terre cuite 1700 kg/m3 ext 1000</option>
<option id='carreaux de gres ceramique 2000 kg/m3 int 1200'>carreaux de gres ceramique 2000 kg/m3 int 1200</option>
<option id='carreaux de gres ceramique 2000 kg/m3 ext 1300'>carreaux de gres ceramique 2000 kg/m3 ext 1300</option>
<option id='carreaux de pvc 1200 kg/m3 int 0190'>carreaux de pvc 1200 kg/m3 int 0190</option>
<option id='linoleum 1200 kg/m3 int 0190'>linoleum 1200 kg/m3 int 0190</option>
<option id='asphalte coule 2100 kg/m3 0700'>asphalte coule 2100 kg/m3 0700</option>
<option id='membrane bitumee 1100 kg/m3 0230'>membrane bitumee 1100 kg/m3 0230</option>
<option id='panneaux de fibreciment 14001900 kg/m3 int 0350'>panneaux de fibreciment 14001900 kg/m3 int 0350</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <p class="lead">Surface &amp; volume pièce</p>
        <table class="table table-bordered table-primary" style="">
          <thead>
            <tr>
              <th>#</th>
              <th>Largeur (m)</th>
              <th>Longueur (m)</th>
              <th>Hauteur (m)</th>
              <th contenteditable="true" spellcheckker="false">Superficie</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                </div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                </div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                </div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                </div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">4</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                </div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">5</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <label></label>
                </div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <p class="lead">Parois froides et fenêtres</p>
        <table class="table table-bordered table-info" style="">
          <thead>
            <tr>
              <th>#</th>
              <th>Paroi</th>
              <th>Largeur (m)</th>
              <th>Longueur (m)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group"></div>
                <div class="form-group">
                  <select class="form-control">
                    <option value="Plafond">Plafond</option>
                    <option value="Mur">Mur</option>
                    <option value="Sol">Sol</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group"></div>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Plafond">Plafond</option>
                    <option value="Mur">Mur</option>
                    <option value="Sol">Sol</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group"></div>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Plafond">Plafond</option>
                    <option value="Mur">Mur</option>
                    <option value="Sol">Sol</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">4</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group"></div>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Plafond">Plafond</option>
                    <option value="Mur">Mur</option>
                    <option value="Sol">Sol</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">5</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group"></div>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Plafond">Plafond</option>
                    <option value="Mur">Mur</option>
                    <option value="Sol">Sol</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">6</th>
              <td>
                <div class="form-group"></div>
                <div class="form-group"></div>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Plafond">Plafond</option>
                    <option value="Mur">Mur</option>
                    <option value="Sol">Sol</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group"></div>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <p class="lead">Radiateurs</p>
        <table class="table table-bordered table-success" style="">
          <thead>
            <tr>
              <th>#</th>
              <th>Type 1</th>
              <th>Type 2</th>
              <th contenteditable="true" spellcheckker="false">Type 3</th>
              <th contenteditable="true" spellcheckker="false">Longueur (m)</th>
              <th contenteditable="true" spellcheckker="false">Hauteur (m)</th>
              <th contenteditable="true" spellcheckker="false">Surface (m²)</th>
              <th contenteditable="true" spellcheckker="false">Puissance W</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                    <option value="Acier">Acier</option>
                    <option value="Aluminium">Aluminium</option>
                    <option value="Fonte">Fonte</option>
                    <option value="Plancher-chauffant">Plancher-chauffant</option>
                    <option value="Ventilo-convecteur">Ventilo-convecteur</option>
                    
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                    <option value="value1">Simple</option>
                    <option value="value2">Double</option>
                    <option value="value3">Triple</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                    <option value="2">2 (7cm)</option>
                    <option value="4">4 (14cm)</option>
                    <option value="6">6 (21cm)</option>
                    <option value="8">8 (28cm)</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Acier">Acier</option>
                    <option value="Aluminium">Aluminium</option>
                    <option value="Fonte">Fonte</option>
                    <option value="Plancher-chauffant">Plancher-chauffant</option>
                    <option value="Ventilo-convecteur">Ventilo-convecteur</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="value1">Simple</option>
                    <option value="value2">Double</option>
                    <option value="value3">Triple</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="2">2 (7cm)</option>
                    <option value="4">4 (14cm)</option>
                    <option value="6">6 (21cm)</option>
                    <option value="8">8 (28cm)</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Acier">Acier</option>
                    <option value="Aluminium">Aluminium</option>
                    <option value="Fonte">Fonte</option>
                    <option value="Plancher-chauffant">Plancher-chauffant</option>
                    <option value="Ventilo-convecteur">Ventilo-convecteur</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="value1">Simple</option>
                    <option value="value2">Double</option>
                    <option value="value3">Triple</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="2">2 (7cm)</option>
                    <option value="4">4 (14cm)</option>
                    <option value="6">6 (21cm)</option>
                    <option value="8">8 (28cm)</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">4</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Acier">Acier</option>
                    <option value="Aluminium">Aluminium</option>
                    <option value="Fonte">Fonte</option>
                    <option value="Plancher-chauffant">Plancher-chauffant</option>
                    <option value="Ventilo-convecteur">Ventilo-convecteur</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="value1">Simple</option>
                    <option value="value2">Double</option>
                    <option value="value3">Triple</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="2">2 (7cm)</option>
                    <option value="4">4 (14cm)</option>
                    <option value="6">6 (21cm)</option>
                    <option value="8">8 (28cm)</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">5</th>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="Acier">Acier</option>
                    <option value="Aluminium">Aluminium</option>
                    <option value="Fonte">Fonte</option>
                    <option value="Plancher-chauffant">Plancher-chauffant</option>
                    <option value="Ventilo-convecteur">Ventilo-convecteur</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="value1">Simple</option>
                    <option value="value2">Double</option>
                    <option value="value3">Triple</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <select class="form-control">
                  <option value="2">2 (7cm)</option>
                    <option value="4">4 (14cm)</option>
                    <option value="6">6 (21cm)</option>
                    <option value="8">8 (28cm)</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control">
                </div>
              </td>
            </tr>
            <tr></tr>
          </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</form>
						</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
        <script> 

</script>
	</body>
</html>