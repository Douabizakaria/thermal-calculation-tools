<?php
    // session start
    if(!empty($_SESSION)){ }else{ session_start(); }
    //session
	if(!empty($_SESSION['ADMIN'])){ }else{ header('location:login.php'); }
    // panggil file
    require 'proses/panggil.php';
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Ajouter un Client</title>
        <link rel="stylesheet" href="../../assets/css/bootstrap.css?v=<?=time();?>">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
    <body style="background:#a2c31b;">
	<body class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <b>
                        
                        <img src="../../assets/img/ENYS.png" style="height: 50px;
    display: block;">
                    </b>
                </a>
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation"></button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <?php if(!empty($_SESSION['ADMIN'])){?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Tableau de bord</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php?hal=profil">
                                Modifier le compte
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../proses.php?aksi=logout">
                                    <i class="fa fa-sign-out"></i> Se déconnecter
                                </a>
                            </li>
                        <?php }else{?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Accueil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="login.php">
                                    <i class="fa fa-sign-in"></i> Connectez-vous ici
                                </a>
                            </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
        </nav>
		<div class="container">
			<br/>
            
			<br/><br/><br/>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-lg-6">
					<br/>
					<div class="card">
						<div class="card-header">
						<h4 class="card-title">Ajouter Client</h4>
						</div>
						<div class="card-body">
							<form action="proses/crud.php?aksi=tambah" method="POST">
								<div class="form-group">
									<label>Nom du client </label>
									<input type="text" value="" class="form-control" name="nom">
								</div>
								<div class="form-group">
									<label>Adresse du chantier </label>
									<input type="text" value="" class="form-control" name="adress">
								</div>
								<div class="form-group">
									<label>Date de la visite</label>
									<input type="date" value="" class="form-control" name="date">
								</div>
								
								<button class="btn btn-primary btn-md" name="create"><i class="fa fa-plus"> </i> Ajouter des données</button>
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
	</body>
</html>