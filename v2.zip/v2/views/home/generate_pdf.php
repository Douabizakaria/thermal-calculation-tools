<?php
require '../../vendor/autoload.php';
require 'cnx.php'; // Change this to the path to your database connection file

$id = $_GET['id'];
$client = $pdo->query('SELECT * FROM tbl_client WHERE id_client = ' . $id)->fetch();
$pieces = $pdo->query('SELECT * FROM tbl_piece WHERE id_client = ' . $id)->fetchAll();

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

$pdf->Cell(40, 10, 'Client Name: ' . $client['nom_client']);
$pdf->Ln();
$pdf->Cell(40, 10, 'Address: ' . $client['adress']);
$pdf->Ln();
$pdf->Cell(40, 10, 'Date of Visit: ' . $client['date_visite']);
$pdf->Ln();

$pdf->SetFont('Arial', 'B', 14);
$pdf->Ln();
$pdf->Cell(40, 10, 'Pieces:');
$pdf->Ln();
$pdf->SetFont('Arial', '', 12);

foreach ($pieces as $piece) {
    $pdf->Cell(40, 10, $piece['piece_name'] . ': ' . $piece['piece_description']);
    $pdf->Ln();
}

$pdf->Output();
?>
