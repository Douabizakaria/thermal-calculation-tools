<?php
    require 'panggil.php';

    // proses tambah
    if(!empty($_GET['aksi'] == 'tambah'))
    {
        $nom = strip_tags($_POST['nom']);
        $desc = strip_tags($_POST['desc']);
        $id_cl = strip_tags($_POST['client_id']);
        
        $tabel = 'tbl_piece';
        # proses insert
        $data[] = array(
            'piece_name'		=>$nom,
            'piece_description'	=>$desc,
            'id_client'		=>$id_cl
           
        );
        $proses->tambah_data($tabel,$data);
      //  echo '<script>alert("succès");window.location="../piece.php"</script>';
           echo '<script>alert("succès");window.location="../add_p2.php"</script>';
    }

    // proses edit
	if(!empty($_GET['aksi'] == 'edit'))
	{
        $nom = strip_tags($_POST['nom']);
        $desc = strip_tags($_POST['desc']);
        $id_cl = strip_tags($_POST['client_id']);
		
        // jika password tidak diisi
       
            $data = array(
                'piece_name'		=>$nom,
                'piece_description'	=>$desc,
                'id_client'		=>$id_cl
            );
   
        $tabel = 'tbl_piece';
        $where = 'id_piece';
        $id = strip_tags($_POST['id_piece']);
         $proses->edit_data($tabel,$data,$where,$id);
        echo '<script>alert("Réussite de la modification des données");window.location="../piece.php"</script>';
    }
    
    // hapus data
    if(!empty($_GET['aksi'] == 'hapus'))
    {
        $tabel = 'tbl_piece';
        $where = 'id_piece';
        $id = strip_tags($_GET['id_piece']);
        $proses->hapus_data($tabel,$where,$id);
        echo '<script>alert("Supp avec success");window.location="../piece.php"</script>';
    }

    // login
    if(!empty($_GET['aksi'] == 'login'))
    {   
        // validasi text untuk filter karakter khusus dengan fungsi strip_tags()
        $user = strip_tags($_POST['user']);
        $pass = strip_tags($_POST['pass']);
        // panggil fungsi proses_login() yang ada di class prosesCrud()
        $result = $proses->proses_login($user,$pass);
        if($result == 'gagal')
        {
            echo "<script>window.location='../login.php?get=gagal';</script>";
        }else{
            // status yang diberikan 
            session_start();
            $_SESSION['ADMIN'] = $result;
            // status yang diberikan 
            echo "<script>window.location='../index.php';</script>";
        }
    }
?>