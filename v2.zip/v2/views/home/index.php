
<div class="row">
    <div class="col-lg-12">
        <?php if(!empty($_SESSION['ADMIN'])){?>
            <div class="alert alert-warning mt-5 alert-dismissible fade show" role="alert">
                <strong> 
                    <i class="fa fa-check"></i>
                    Bienvenue 
                    <?php echo $_SESSION['ADMIN']['nama_pengguna'];?>
                </strong> 
            </div>
            <div class="card mt-2">
                <div class="card-header">
                Tableau de bord
                </div>
                <div class="card-body">
                
                <a href="./views/home/client.php" class="btn btn-success btn-lg"><span class="fa fa-plus"></span> Info du Client</a></br></br>
                <a href="./views/home/piece.php" class="btn btn-success btn-lg"><span class="fa fa-plus"></span> SYNTHESE PIECE	</a></br></br>
                <a href="./views/home/synt.php" class="btn btn-success btn-lg"><span class="fa fa-plus"></span> SYNTHESE GLOBALE</a>

                </div>
            </div>
        <?php }else{?>
            <div class="card mt-5">
                <div class="card-header">
                    Home
                </div>
                <div class="card-body">
                    <div class="alert alert-danger mt-2">
                        <h5> <i class="fa fa-ban"></i>
                        Désolé, vous ne pouvez pas accéder au site Web,
                             S'il vous plait Connectez-vous d'abord!
                        </h5>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>