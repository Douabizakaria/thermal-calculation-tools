<div class="row">
    <div class="col-sm-12">
        <div class="card mt-5">
            <div class="card-header">
                Halaman 404
            </div>
            <div class="card-body text-center">
                <div class="alert alert-danger mt-2 text-center">
                    <strong> <i class="fa fa-ban"></i>
                        Maaf Halaman Yang Anda Cari Tidak Ditemukan !
                    </strogn>
                </div>
                <a class="btn btn-primary" href="index.php" role="button">
                    <i class="fa fa-home"></i> Kembali 
                </a>
            </div>
        </div>
    </div>
</div>
