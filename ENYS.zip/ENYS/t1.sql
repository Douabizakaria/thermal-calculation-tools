-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : lun. 21 août 2023 à 13:00
-- Version du serveur : 5.7.39
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `t1`
--

-- --------------------------------------------------------

--
-- Structure de la table `tbl_client`
--

CREATE TABLE `tbl_client` (
  `id_client` int(30) NOT NULL,
  `nom_client` varchar(260) NOT NULL,
  `adress` varchar(260) NOT NULL,
  `date_visite` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tbl_client`
--

INSERT INTO `tbl_client` (`id_client`, `nom_client`, `adress`, `date_visite`) VALUES
(1, 'EDF', '2323 23 ', '2023-08-17'),
(2, 'BOUYGS', '23232 grenoble', '2023-08-17'),
(3, 'DD', 'DSS', '2023-08-12'),
(4, 'DD2', 'DSS', '2023-08-12'),
(5, 'SED', '23123S', '1999-12-12'),
(6, 'FREEFR', '2323', '2023-07-06'),
(7, 'ee', '23233', '2023-08-10');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_mahasiswa`
--

CREATE TABLE `tbl_mahasiswa` (
  `id` int(11) NOT NULL,
  `npm` varchar(25) DEFAULT NULL,
  `nama_siswa` varchar(255) DEFAULT NULL,
  `fakultas` varchar(255) DEFAULT NULL,
  `tahun` int(11) NOT NULL,
  `tgl_buat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_piece`
--

CREATE TABLE `tbl_piece` (
  `id_piece` int(30) NOT NULL,
  `piece_name` varchar(260) NOT NULL,
  `piece_description` varchar(500) DEFAULT NULL,
  `id_client` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tbl_piece`
--

INSERT INTO `tbl_piece` (`id_piece`, `piece_name`, `piece_description`, `id_client`) VALUES
(1, 'CUISINE', 'CUISINE DE JACK', 1),
(2, 'SALLE', 'SSDSD', 3),
(3, 'E34F', 'ERCERC', 6),
(4, 'asas', 'asas', 1),
(5, 'CUISINE INTERNE', 'EEE', 7),
(6, 'ads', 'sddada', 3);

-- --------------------------------------------------------

--
-- Structure de la table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_login` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_pengguna` varchar(255) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tbl_user`
--

INSERT INTO `tbl_user` (`id_login`, `username`, `password`, `nama_pengguna`, `telepon`, `email`, `alamat`) VALUES
(2, 'admin', '202cb962ac59075b964b07152d234b70', 'ZAKARIA BS', '081298669897', 'ZAKARIA@LIVE.FR', 'PARIS');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `tbl_client`
--
ALTER TABLE `tbl_client`
  ADD PRIMARY KEY (`id_client`);

--
-- Index pour la table `tbl_mahasiswa`
--
ALTER TABLE `tbl_mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_piece`
--
ALTER TABLE `tbl_piece`
  ADD PRIMARY KEY (`id_piece`),
  ADD KEY `id_client` (`id_client`);

--
-- Index pour la table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_login`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `tbl_client`
--
ALTER TABLE `tbl_client`
  MODIFY `id_client` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `tbl_mahasiswa`
--
ALTER TABLE `tbl_mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tbl_piece`
--
ALTER TABLE `tbl_piece`
  MODIFY `id_piece` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `tbl_piece`
--
ALTER TABLE `tbl_piece`
  ADD CONSTRAINT `tbl_piece_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `tbl_client` (`id_client`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
