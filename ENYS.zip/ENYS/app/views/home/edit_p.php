<?php
    // session start
    if(!empty($_SESSION)){ }else{ session_start(); }
    //session
	if(!empty($_SESSION['ADMIN'])){ }else{ header('location:login.php'); }
    // panggil file
    require 'p_controller/panggil.php';
    
    // tampilkan form edit
    $idGet = strip_tags($_GET['id']);
    $hasil = $proses->tampil_data_id('tbl_piece','id_piece',$idGet);
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Modifier Client</title>
        <link rel="stylesheet" href="../../assets/css/bootstrap.css?v=<?=time();?>">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
    <body style="background:#a2c31b;">
	<body class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <b>
                        
                        <img src="../../assets/img/ENYS.png" style="height: 50px;
    display: block;">
                    </b>
                </a>
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation"></button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <?php if(!empty($_SESSION['ADMIN'])){?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Tableau de bord</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php?hal=profil">
                                Modifier le compte
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../proses.php?aksi=logout">
                                    <i class="fa fa-sign-out"></i> Se déconnecter
                                </a>
                            </li>
                        <?php }else{?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Accueil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="login.php">
                                    <i class="fa fa-sign-in"></i> Connectez-vous ici
                                </a>
                            </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
        </nav>
		<div class="container">
			<br/>
				
			<br/><br/><br/>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-lg-6">
					<br/>
                    <?php  
                                    $clients = $proses->tampil_data('tbl_client');
                                ?>
					<div class="card">
						<div class="card-header">
						<h4 class="card-title">Modifier la Piece - <?php echo $hasil['piece_name'];?></h4>
						</div>
						<div class="card-body">
						
							<form action="p_controller/crud.php?aksi=edit" method="POST">
								<div class="form-group">
									<label>Nom du Piece </label>
									<input type="text" value="<?php echo $hasil['piece_name'];?>" class="form-control" name="nom">
								</div>
								<div class="form-group">
									<label>Description de Piece </label>
									<input type="text" value="<?php echo $hasil['piece_description'];?>" class="form-control" name="desc">
								</div>
                                <div class="form-group">
                                <label for="client">Choisir le client </label>
        <select class="form-control" name="client_id" required>
            <?php foreach ($clients as $client): ?>
                <option value="<?= htmlspecialchars($client['id_client']) ?>"><?= htmlspecialchars($client['nom_client']) ?></option>
            <?php endforeach; ?>
        </select><br><br>
								</div>
								
								<button class="btn btn-primary btn-md" name="create"><i class="fa fa-edit"> </i> Modifier La Piece</button>
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
	</body>
</html>