<?php
    // session start
    if(!empty($_SESSION)){ }else{ session_start(); }
    require 'p_controller/panggil.php';
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Gestion Des Pieces</title>
		<!-- BOOTSTRAP 4-->
        <link rel="stylesheet" href="../../assets/css/bootstrap.css?v=<?=time();?>">
        <!-- DATATABLES BS 4-->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" />
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- jQuery -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
        <!-- DATATABLES BS 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <!-- BOOTSTRAP 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

	</head>
    <body style="background:#a2c31b;">
    <!DOCTYPE HTML>
<html>
	<head>
		<title>
            <?= $title_project;?> 
        </title>
		<!-- BOOTSTRAP 4-->
        <link rel="stylesheet" href="assets/css/bootstrap.css?v=<?=time();?>">
        <!-- DATATABLES BS 4-->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" />
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/main.css?v=<?=time();?>">
        <!-- jQuery -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
        <!-- BOOTSTRAP 4-->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
        <!-- DATATABLES BS 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

	</head>
    <body class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <b>
                        
                        <img src="../../assets/img/ENYS.png" style="height: 50px;
    display: block;">
                    </b>
                </a>
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation"></button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <?php if(!empty($_SESSION['ADMIN'])){?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Tableau de bord</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php?hal=profil">
                                Modifier le compte
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../proses.php?aksi=logout">
                                    <i class="fa fa-sign-out"></i> Se déconnecter
                                </a>
                            </li>
                        <?php }else{?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Accueil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="login.php">
                                    <i class="fa fa-sign-in"></i> Connectez-vous ici
                                </a>
                            </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
        </nav>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">

                    <?php if(!empty($_SESSION['ADMIN'])){?>
                    <br/>
   
                    <a href="add_p.php" class="btn btn-success btn-md"><span class="fa fa-plus"></span> Ajouter</a>
                    <br/><br/>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Gestion des pièces</h4>
                        </div>
                        <div class="card-body">
                            <table class="table table-hover table-bordered" id="mytable" style="margin-top: 10px">
                                <thead>
                                    <tr>
                                        <th width="50px">No</th>
                                        <th>Nom de la Pièce</th>
                                        <th>Description de la Pièce </th>
                                        <th>Client</th>
                                        
                                        <th style="text-align: center;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $no=1;
                                    $hasil = $proses->tampil_data2('tbl_piece');
                                    foreach($hasil as $isi){
                                ?>
                                    <tr>
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $isi['piece_name']?></td>
                                        <td><?php echo $isi['piece_description'];?></td>
                                        <td><?php echo $isi['nom_client'];?></td>
                                      
                                        <td style="text-align: center;">
                                            <a href="edit_p.php?id=<?php echo $isi['id_piece'];?>" class="btn btn-success btn-md">
                                            <span class="fa fa-edit"></span></a>
                                            <a onclick="return confirm('Êtes-vous sûr que les données seront supprimées ?')" href="proses/crud.php?aksi=hapus&hapusid=<?php echo $isi['id_client'];?>" 
                                            class="btn btn-danger btn-md"><span class="fa fa-trash"></span></a>
                                        </td>
                                    </tr>
                                <?php
                                    $no++;
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php }else{?>
                        <br/>
                        <div class="alert alert-info">
                            <h3> Désolé, vous ne pouvez pas encore accéder , veuillez d'abord vous connecter !</h3>
                            <hr/>
                            <p><a href="../../login.php">Connectez-vous ici</a></p>
                        </div>
                    <?php }?>
			    </div>
			</div>
		</div>
        <script>
            $('#mytable').dataTable();
        </script>
	</body>
</html>
