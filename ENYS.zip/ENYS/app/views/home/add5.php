<?php
    // session start
    if(!empty($_SESSION)){ }else{ session_start(); }
    //session
	if(!empty($_SESSION['ADMIN'])){ }else{ header('location:login.php'); }
    // panggil file
    require 'proses/panggil.php';
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Ajouter un Client</title>
        <link rel="stylesheet" href="../../assets/css/bootstrap.css?v=<?=time();?>">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
    <body style="background:#a2c31b;">
	<body class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <b>
                        
                        <img src="../../assets/img/ENYS.png" style="height: 50px;
    display: block;">
                    </b>
                </a>
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation"></button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <?php if(!empty($_SESSION['ADMIN'])){?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Tableau de bord</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php?hal=profil">
                                Modifier le compte
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../proses.php?aksi=logout">
                                    <i class="fa fa-sign-out"></i> Se déconnecter
                                </a>
                            </li>
                        <?php }else{?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Accueil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="login.php">
                                    <i class="fa fa-sign-in"></i> Connectez-vous ici
                                </a>
                            </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
        </nav>
		<div class="container">
			<br/>
            
			<br/><br/><br/>
			<div class="row">
				<div class="col-sm-4"></div>
				<div class="col-lg-10">
					<br/>
					<div class="card">
						<div class="card-header">
						<h4 class="card-title">Données de Client</h4>
						</div>
						<div class="card-body">
                        <form action="client.php" method="POST">
  <div class="container">
    <div class="row">
      <div class="col" style="background-color: rgb(139, 175, 223);">
        <div class="form-group">
          <p class="lead">Consommations annuelles ENERGIE</p>
        </div>
        <table class="table table-primary table-bordered" style="">
          <thead class="">
            <tr></tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Fioul</th>
              <td>
                <div class="form-group">
                  <select class="form-control required" required="required">
                    <option value="l">Litres</option>
                    <option value="kwh">Kwh</option>
                 
                  </select>
                </div>
              </td>
              <td>
              
    
                <div class="form-group">
                  <input type="number" class="form-control required" required="required" style="position: static;">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">Gaz</th>
              <td>
                <br>
                <div class="form-group">
                  <select class="form-control required" required="required">
                    <option value="m3">m3</option>
                    <option value="kwh">kwh</option>
                   
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                        </br>
                  <input type="number" class="form-control required" required="required">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">Electricité</th>
              <td>
                <br>
                <div class="form-group">
                  <select class="form-control required" required="required">
                    <option value="kwh">kwh</option>                   
                  </select>
                </div>
              </td>
              <td>
                <br>
                <div class="form-group">
                  <input type="number" class="form-control required" required="required">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">Pellet</th>
              <td>
                <div class="form-group">
                  <select class="form-control required" required="required">
                    <option value="kg">kg</option>
                    <option value="kwh">kwh</option>
                    
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control required" required="required" style="position: static;">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">Bois</th>
              <td>
                <div class="form-group">
                  <select class="form-control required" required="required">
                    <option value="value1">steres</option>
                    <option value="value2">kwh</option>
                  </select>
                </div>
              </td>
              <td>
                <div class="form-group">
                  <input type="number" class="form-control required" required="required" style="position: static;">
                </div>
              </td>
            </tr>
            
          </tbody>
        </table>
                        </br>
        <button type="submit" class="btn btn-primary">Confirmer</button>
        </br>

      </div>
    </div>
    </br>
  </div>
</form>

						</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
        <script> 


</script>
	</body>
</html>