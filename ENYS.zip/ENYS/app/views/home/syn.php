<?php
$host = 'localhost';
$db   = 't1';
$user = 'root';
$pass = 'root';
$charset = 'utf8';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);
?>
<?php
$clients = $pdo->query('SELECT * FROM tbl_client')->fetchAll();
?>

<table>
    <thead>
        <tr>
            <th>Client Name</th>
            <th>Address</th>
            <th>Date of Visit</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($clients as $client): ?>
        <tr>
            <td><?= $client['nom_client'] ?></td>
            <td><?= $client['adress'] ?></td>
            <td><?= $client['date_visite'] ?></td>
            <td><a href="generate_pdf.php?id=<?= $client['id_client'] ?>">Generate PDF</a></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
