<?php
    // session start
    if(!empty($_SESSION)){ }else{ session_start(); }
    //session
	if(!empty($_SESSION['ADMIN'])){ }else{ header('location:login.php'); }
    // panggil file
    require 'proses/panggil.php';
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Ajouter un Client</title>
        <link rel="stylesheet" href="../../assets/css/bootstrap.css?v=<?=time();?>">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
    <body style="background:#a2c31b;">
	<body class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <b>
                        
                        <img src="../../assets/img/ENYS.png" style="height: 50px;
    display: block;">
                    </b>
                </a>
                <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation"></button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <?php if(!empty($_SESSION['ADMIN'])){?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Tableau de bord</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php?hal=profil">
                                Modifier le compte
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../proses.php?aksi=logout">
                                    <i class="fa fa-sign-out"></i> Se déconnecter
                                </a>
                            </li>
                        <?php }else{?>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../index.php">Accueil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="login.php">
                                    <i class="fa fa-sign-in"></i> Connectez-vous ici
                                </a>
                            </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
        </nav>
		<div class="container">
			<br/>
            
			<br/><br/><br/>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-lg-6">
					<br/>
					<div class="card">
						<div class="card-header">
						<h4 class="card-title">Données de Zone Client</h4>
						</div>
						<div class="card-body">
                        <form action="add4.php" method="POST">
                            <div class="container">
    <div class="row">
      <div class="col">
        <div class="form-group">
          
          <div class="form-group">
            <label>Choisir une zone</label>
  <select id="countryDropdown">
    <option value="Meurtheetmoselle">Meurtheetmoselle</option>
    <option value="Moselle">Moselle</option>
    <option value="Paris">Paris</option>
    <option value="Seineetmarne">Seineetmarne</option>
    <option value="Yvelines">Yvelines</option>
    <option value="Vosges">Vosges</option>
    <option value="Essonne">Essonne</option>
    <option value="Seinestdenis">Seinestdenis</option>
    <option value="Valdoise">Valdoise</option>
                       
</select>

</br>

            <div class="form-group">
            <label>--></label>             
              <select id="cityDropdown">
    
</select>
</br>
              <div class="form-group">
                <label>Temp. Extérieure AIR</label>
                <input type="number" class="form-control">
                <div class="form-group">
                  <label>Temp. Extérieure SOL</label>
                  <input type="number" class="form-control">
                  <div class="form-group">
                    <label>Habitude de chauffe</label>
                    <input type="number" class="form-control">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Continue</button>
      </div>
    </div>
  </div>
</form>
						</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
        <script> 
document.getElementById('countryDropdown').addEventListener('change', function() {
    var country = this.value;
    var cityDropdown = document.getElementById('cityDropdown');
    
    // Clear out any old options
    cityDropdown.innerHTML = "";

    var cities = [];

    switch(country) {
        case 'Meurtheetmoselle':
            cities = ["Nancy Essey", "Nancy Ochey"];
            break;
        case 'Moselle':
            cities = ["Metz Frescaty", "Metz Nancy Lorraine", "Buhl Lorraine", "Serémange-Erzange"];
            break;
        case 'Paris':
            cities = ["Paris Montsouris"];
            break;
        case 'Seineetmarne':
            cities = ["Melun Villaroche"];
            break; 
        case 'Yvelines':
            cities = ["Trappes", "Toussus le noble", "Villacoublay Velizy"];
            break;
        case 'Vosges':
            cities = ["Epinal", "Bellefontaine", "Rupt Sur Moselle"];
            break;
        case 'Essonne':
            cities = ["Orly Athis Mons"];
            break;
        case 'Seinestdenis':
            cities = ["Le Bourget"];
            break;
        case 'Valdoise':
            cities = ["Roissy Charles de Gaulle", "Pontoise", "Argenteuil"];
            break;        
        // ... Add more countries and their cities here ...
    }

    for(var i = 0; i < cities.length; i++) {
        var option = document.createElement("option");
        option.text = cities[i];
        option.value = cities[i];
        cityDropdown.appendChild(option);
    }
});

// To populate the city dropdown initially (e.g., with USA cities)
document.getElementById('countryDropdown').dispatchEvent(new Event('change'));

</script>
	</body>
</html>